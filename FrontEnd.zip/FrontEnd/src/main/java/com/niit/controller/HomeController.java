package com.niit.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import model.Category;
import model.CategoryDAO;
import model.Product;
import model.ProductDAO;

@Controller
public class HomeController {

	
	@RequestMapping(value="/")
	public ModelAndView indexpage()
	{
		ModelAndView m1=new ModelAndView("index");
		Product p=new Product();
		return m1;
	}
	@RequestMapping(value="/product")
	public ModelAndView add()
	{
		ModelAndView m1=new ModelAndView("Product");
		return m1;
	}
	@RequestMapping(value="/addproduct")
	public ModelAndView addproduct1(HttpServletRequest request)
	{
		
		int id = Integer.parseInt(request.getParameter("t1"));
		String pname = request.getParameter("t3");
		int pcost = Integer.parseInt(request.getParameter("t2"));
		
		if(id != 0)
		{
			Product p = new Product();
			p.setPid(id);
			p.setPname(pname);
			p.setPcost(pcost);
			ProductDAO pd = new ProductDAO();
			boolean b = pd.insertProduct(p);
			
		}
		ModelAndView m2=new ModelAndView("sucess");
		return m2;
	}
	@RequestMapping(value="/category")
	public ModelAndView addcategorypage()
	{
		ModelAndView m3=new ModelAndView("AddCategory");
		return m3;
	}
	@RequestMapping(value="/InsertCategory")
	public ModelAndView addcategory(HttpServletRequest request)
	{
		int cid=Integer.parseInt(request.getParameter("cid"));
		String cname=request.getParameter("cname");
		if(cid!=0){
			Category cd=new Category();
			cd.setCid(cid);
			cd.setCname(cname);
			CategoryDAO cd1=new CategoryDAO();
			boolean b=cd1.insertCategory(cd);
		}
		ModelAndView m4=new ModelAndView("AddCategory");
		return m4;
	}
	@RequestMapping(value="/viewproducts")
	public ModelAndView viewproducts()
	{
		ProductDAO p1=new ProductDAO();
		List<Product> list=p1.getProducts();
		
		ModelAndView m4=new ModelAndView("viewproductdetails");
		m4.addObject("clist",list);
		return m4;
	}
	@RequestMapping(value="/product_edit")
	 
	 public ModelAndView editProducts(HttpServletRequest request)
	{
		
	ProductDAO p1=new ProductDAO();
	 int id=Integer.parseInt(request.getParameter("id"));
	 
	 List<Product> list=p1.getProducts();
	 ModelAndView mv=new ModelAndView("sucess");
	 mv.addObject("product",p1.findById(id));	
//	 mv.addObject("slist", list);

	 return mv;
	 }
	@RequestMapping(value="/updateproduct")
	public ModelAndView updateproduct1(HttpServletRequest request)
	{
		
		int id = Integer.parseInt(request.getParameter("t1"));
		
		String pname = request.getParameter("t3");
		int pcost = Integer.parseInt(request.getParameter("t2"));
		if(id != 0)
		{
		
			Product p = new Product();
			p.setPid(id);
			p.setPcost(pcost);
			p.setPname(pname);
			
			ProductDAO pd = new ProductDAO();
			boolean b = pd.updateProduct(p);
		}
		
		ModelAndView m2=new ModelAndView("index");
		return m2;
	}
	@RequestMapping(value="/product_delete")
	public ModelAndView deleteProduct(HttpServletRequest request)throws NullPointerException
	{
		
       ProductDAO c1=new ProductDAO();
		int cid=Integer.valueOf(request.getParameter("id"));
		Product c=c1.getProduct(cid);
		c1.delete(c);
		
		ModelAndView mv=new ModelAndView("viewproductdetails");
		List<Product> list=c1.getProducts();
		
		mv.addObject("clist", list);
		return mv;
	}
	
	
}
