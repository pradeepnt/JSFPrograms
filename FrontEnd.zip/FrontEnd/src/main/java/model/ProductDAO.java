package model;


import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.stereotype.Repository;
@Repository("productDAO")
public class ProductDAO
{
	
	private Transaction trans;
	private Session sess;
	private boolean b = true;
	public boolean insertProduct(Product p)
	{
		try
		{
	    DbConfig db = new DbConfig();
		 sess = db.getSess();
		 trans = sess.beginTransaction();
		// Product p1 =(Product)sess.get(Product.class, p.getPid());
		//sess.delete(p1);
		sess.save(p);
		trans.commit();
		}catch(Exception ex)
		{
			ex.printStackTrace();
			trans.rollback();
			b = false;
		}
		return b;
	}
	public List<Product> getProducts()
	{
		DbConfig db=new DbConfig();
		sess=db.getSess();
		trans=sess.beginTransaction();
		Query query=sess.createQuery("from Product");
		List<Product> list =query.list();
		System.out.println(list);
		trans.commit();
		return list;
		
	}

	public boolean updateProduct(Product p)
	{
		try
		{
		DbConfig db = new DbConfig();
		 sess = db.getSess();
		 trans = sess.beginTransaction();
		// Product p1 =(Product)sess.get(Product.class, p.getPid());
		//sess.delete(p1);
		sess.update(p);
		trans.commit();
		}catch(Exception ex)
		{
			ex.printStackTrace();
			trans.rollback();
			b = false;
		}
		return b;
	}
	public Product findById(int id) 
	{
		//return (Product)sessionFactory.openSession().get(Product.class,id);
		return (Product)sess.get(Product.class,id);
	}

	
	public void delete(Product p)
	{
		
		   System.out.println("IN");
			DbConfig db = new DbConfig();
			sess = db.getSess();
			trans = sess.beginTransaction();
			Product p1 =(Product)sess.get(Product.class, p.getPid());
			 
			sess.delete(p1);
			 trans.commit();
			
			 //sess.close();sess.delete(p);
		
	}
	public Product getProduct(int id)
	{
		DbConfig db = new DbConfig();
		sess = db.getSess();
		return (Product)sess.get(Product.class, Integer.valueOf(id));
	}
}