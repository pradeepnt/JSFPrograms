package model;


import org.hibernate.Session;
import org.hibernate.Transaction;

public class CategoryDAO {
	private Transaction trans;
	private Session sess;
	private boolean b=true;
	public boolean insertCategory(Category c) {
		try{
			DbConfig db=new DbConfig();
			sess=db.getSess();
			trans=sess.beginTransaction();
			sess.save(c);
			trans.commit();
		}
		catch(Exception ex){
			ex.printStackTrace();
			trans.rollback();
			b=false;
		}
		return b;
	}
	

}
